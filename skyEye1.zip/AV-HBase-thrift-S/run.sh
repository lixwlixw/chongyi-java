LIB=$PATH
for jarfile in `ls /home/demo/AV/lib/*.jar`
do
 export LIB=$LIB:$jarfile
done

#echo CLASSPATH=$CLASSPATH

java -cp  $LIB:AV-HBase-thrift-S.jar com.main.AV_HBase_Thrift_S >>1.log 2>&1 &

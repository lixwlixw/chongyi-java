LIB=$PATH
for jarfile in `ls /home/demo/AV/lib/*.jar`
do
 export LIB=$LIB:$jarfile
done

#echo CLASSPATH=$CLASSPATH

java -cp  $LIB:AV-Master.jar com.main.AV_Master >>1.log 2>&1 &
